# Evaluation Summary

| Metric | Value |
|---|---:|
| Samples | 320 |
| Weather accuracy | 0.987500 |
| Weather macro F1 | 0.987499 |
| Object mAP | 0.727999 |
| Object macro F1 | 0.727626 |
| Object Hamming loss | 0.170660 |

## Weather Confusion Matrix

| true \ pred | fog | night | rain | snow |
|---|---:|---:|---:|---:|
| fog | 78 | 0 | 2 | 0 |
| night | 0 | 80 | 0 | 0 |
| rain | 0 | 0 | 78 | 2 |
| snow | 0 | 0 | 0 | 80 |
