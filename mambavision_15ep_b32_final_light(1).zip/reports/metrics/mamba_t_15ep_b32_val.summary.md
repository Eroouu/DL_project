# Evaluation Summary

| Metric | Value |
|---|---:|
| Samples | 320 |
| Weather accuracy | 0.968750 |
| Weather macro F1 | 0.968808 |
| Object mAP | 0.692913 |
| Object macro F1 | 0.707608 |
| Object Hamming loss | 0.200174 |

## Weather Confusion Matrix

| true \ pred | fog | night | rain | snow |
|---|---:|---:|---:|---:|
| fog | 77 | 0 | 1 | 2 |
| night | 1 | 79 | 0 | 0 |
| rain | 2 | 0 | 77 | 1 |
| snow | 0 | 0 | 3 | 77 |
